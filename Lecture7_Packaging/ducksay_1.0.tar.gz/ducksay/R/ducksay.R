ducksay <- function() {
  paste(
    "hello, world",
    "   >(.)__",
    "     (___/  ",
    sep = "\n"
  )
}
